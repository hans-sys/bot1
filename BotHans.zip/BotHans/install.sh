apt update
apt upgrade
apt install
pkg update && pkg upgrade
pkg install wget
pkg install ffmpeg
pkg install nodejs
pkg install tesseract
npm i -g cwebp
npm i -g ytdl 
npm i
npm i got
